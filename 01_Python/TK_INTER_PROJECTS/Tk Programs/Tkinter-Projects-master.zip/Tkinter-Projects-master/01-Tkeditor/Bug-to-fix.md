# Bug to fix in Tkeditor
1. The line number and Infobar have Delay of the Cursor.
2. The line number does not scroll with the Scrollbar.
