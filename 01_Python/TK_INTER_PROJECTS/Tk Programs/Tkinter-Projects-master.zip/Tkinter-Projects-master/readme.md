# Tkinter Projects
##Objects
This repository includes several small Tkinter examples according to the book [*Tkinter GUI Application Development*](http://www.amazon.com/Tkinter-ApplicationDevelopment-HOTSHOT-Bhaskar-Chaudhary/dp/1849697949/ref=sr_1_1?ie=UTF8&qid=1449579378&sr=8-1&keywords=Tkinter+GUI+Application+Development).

And aim to solve all **Hotshot Challenges**.