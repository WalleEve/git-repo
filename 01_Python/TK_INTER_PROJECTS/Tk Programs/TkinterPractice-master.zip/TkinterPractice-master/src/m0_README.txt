IMPORTANT:
   *** Your instructor will guide you through this exercise. ***
   
   Your instructor may ask you to watch the video
      called  TkinterPractice   as you do this exercise.
   
If your instructor asks you to watch the video, it will:
1. Explain m1e, then ask you to do TO DO's 1 and 2 in m5.
2. Explain m2e, then ask you to do TO DO's 3 and 4 in m5.
3. Explain m3e, then ask you to do TO DO 5 in m5.
4. Explain m4e, then ask you to do TO DO's 6 and 7 (and optionally 8) in m5.